package electric.dao;

import electric.model.Other;

import java.util.List;

public interface IOther {
    int addOther(Other other);
    List<Other> findAll();
    Other findOther(int id);
}
